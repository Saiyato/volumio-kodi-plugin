# volumio-kodi-plugin
Installation script for Kodi on Volumio images
