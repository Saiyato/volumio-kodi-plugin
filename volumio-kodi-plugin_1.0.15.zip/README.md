# volumio-kodi-plugin
Installation script for Kodi on Volumio 2.x images

Use the zip from the code-section to drop that into the 'upload plugin' field in Volumio.
